# Chime — iOS (and Android) TODO app with real alarms

Built with **Expo / React Native**: one codebase that runs on both iPhone and Android.
Alarms are **local scheduled notifications**, so they ring at the set date & time
**even when the app is closed** — unlike the web version.

## Features
- Title, description, date & time
- Urgent toggle → alarm notification with sound at the exact time
- Repeat: Daily (pick any of Mon–Sun), Weekly, Monthly, Yearly
- End repeat: forever, or until a chosen date
- Completing a recurring task rolls it to its next occurrence
- Tasks persist on the device (AsyncStorage)

## Prerequisites
1. **Node.js LTS** installed on your computer (Windows/Mac/Linux — no Mac required)
2. **Expo Go** app on your iPhone (free, from the App Store) — same for Android via Play Store
3. Phone and computer on the **same Wi-Fi network**

## Setup (about 5 minutes)

```bash
# 1. Create a fresh Expo project
npx create-expo-app@latest chime --template blank
cd chime

# 2. Install the libraries this app uses (expo install picks compatible versions)
npx expo install expo-notifications expo-device @react-native-async-storage/async-storage @react-native-community/datetimepicker

# 3. Replace the generated App.js with the App.js from this folder
#    (copy it over the top of chime/App.js)

# 4. Start the dev server
npx expo start
```

Then open **Expo Go** on your iPhone and scan the QR code shown in the terminal.
The app loads on your phone; allow notifications when prompted.

## Testing an alarm
Add a task with a time 1–2 minutes in the future, enable **Urgent — ring alarm**,
then lock your phone. The notification fires with sound at the set time.

> Note: notifications don't fire in the iOS **Simulator** — test on a real device.
> If notification behavior seems limited inside Expo Go (this varies by Expo SDK
> version, especially on Android), create a development build instead:
> `npx expo run:ios` (needs a Mac) or use a free EAS cloud build:
> `npx eas build --profile development --platform ios`.

## How alarms work here
- Each alarmed task schedules its next occurrences (up to 12) as system
  notifications. iOS allows ~64 pending notifications per app, so schedules are
  refreshed every time you open the app — for everyday use this is seamless.
- Completing or deleting a task cancels its pending notifications.
- End-repeat is enforced when occurrences are generated.

## Shipping it to the App Store (later, optional)
1. Enroll in the Apple Developer Program ($99/yr)
2. `npx eas build --platform ios` (Expo's cloud build — no Mac needed)
3. `npx eas submit --platform ios` to upload to App Store Connect / TestFlight

The same two commands with `--platform android` produce the Play Store build.
