// Chime — TODO with real alarms (iOS + Android, Expo)
// Title, description, date/time, urgency alarm, repeat (daily w/ day picker,
// weekly, monthly, yearly) and end-repeat. Alarms fire as local notifications
// even when the app is closed.

import React, { useEffect, useState, useCallback } from 'react';
import {
  SafeAreaView, ScrollView, View, Text, TextInput, TouchableOpacity,
  Switch, StyleSheet, Platform, Alert, KeyboardAvoidingView,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import DateTimePicker from '@react-native-community/datetimepicker';
import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';

// ---------- Colors (same palette as the web app) ----------
const C = {
  bg: '#F4F6FB', surface: '#FFFFFF', ink: '#141B33', muted: '#6B7590',
  line: '#E1E6F0', cobalt: '#2743E0', cobaltSoft: '#EDF0FF',
  signal: '#FF6A2B', signalSoft: '#FFF0E8', green: '#0E9F6E', greenSoft: '#E6F7F0',
};

const DAY_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const DAY_ORDER = [1, 2, 3, 4, 5, 6, 0]; // Mon..Sun for display
const REPEATS = [
  { key: '', label: 'Never' },
  { key: 'daily', label: 'Daily' },
  { key: 'weekly', label: 'Weekly' },
  { key: 'monthly', label: 'Monthly' },
  { key: 'yearly', label: 'Yearly' },
];
const MAX_SCHEDULED_PER_TASK = 12; // iOS caps ~64 pending notifications app-wide

// ---------- Notifications setup ----------
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

async function ensurePermissions() {
  if (!Device.isDevice) return false; // simulators don't deliver notifications
  const { status } = await Notifications.getPermissionsAsync();
  if (status === 'granted') return true;
  const req = await Notifications.requestPermissionsAsync();
  return req.status === 'granted';
}

async function ensureAndroidChannel() {
  if (Platform.OS !== 'android') return;
  await Notifications.setNotificationChannelAsync('alarms', {
    name: 'Alarms',
    importance: Notifications.AndroidImportance.MAX,
    sound: 'default',
    vibrationPattern: [0, 300, 150, 300],
  });
}

// ---------- Recurrence math ----------
function nextOccurrence(ms, repeat, days) {
  const d = new Date(ms);
  if (repeat === 'daily') {
    const set = days && days.length ? days : [0, 1, 2, 3, 4, 5, 6];
    do { d.setDate(d.getDate() + 1); } while (!set.includes(d.getDay()));
  } else if (repeat === 'weekly') {
    d.setDate(d.getDate() + 7);
  } else if (repeat === 'monthly') {
    const day = d.getDate();
    d.setDate(1); d.setMonth(d.getMonth() + 1);
    const max = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate();
    d.setDate(Math.min(day, max));
  } else if (repeat === 'yearly') {
    const m = d.getMonth(), day = d.getDate();
    d.setDate(1); d.setFullYear(d.getFullYear() + 1); d.setMonth(m);
    const max = new Date(d.getFullYear(), m + 1, 0).getDate();
    d.setDate(Math.min(day, max));
  }
  return d.getTime();
}

// Upcoming occurrences strictly in the future, capped
function upcomingOccurrences(task, count) {
  if (!task.due) return [];
  const out = [];
  let t = task.due;
  const now = Date.now();
  if (t > now) out.push(t);
  while (task.repeat && out.length < count) {
    t = nextOccurrence(t, task.repeat, task.days);
    if (task.endRepeat && t > task.endRepeat) break;
    if (t > now) out.push(t);
  }
  return out;
}

function advanceRecurring(task) {
  if (!task.repeat || !task.due) return false;
  let next = task.due;
  do { next = nextOccurrence(next, task.repeat, task.days); } while (next <= Date.now());
  if (task.endRepeat && next > task.endRepeat) return false;
  task.due = next;
  task.done = false;
  return true;
}

function repeatLabel(t) {
  if (t.repeat === 'daily') {
    const set = t.days && t.days.length ? t.days : [0, 1, 2, 3, 4, 5, 6];
    if (set.length === 7) return 'daily';
    if (set.length === 5 && [1, 2, 3, 4, 5].every((d) => set.includes(d))) return 'weekdays';
    if (set.length === 2 && set.includes(0) && set.includes(6)) return 'weekends';
    return DAY_ORDER.filter((d) => set.includes(d)).map((d) => DAY_SHORT[d]).join(', ');
  }
  return t.repeat;
}

function fmtDue(ms) {
  const d = new Date(ms);
  return (
    d.toLocaleDateString([], { month: 'short', day: 'numeric' }) +
    ' · ' +
    d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  );
}

function countdownText(ms) {
  const diff = ms - Date.now();
  if (diff <= 0) return 'overdue';
  const m = Math.floor(diff / 60000);
  if (m < 60) return 'in ' + (m < 1 ? '<1 min' : m + ' min');
  const h = Math.floor(m / 60);
  if (h < 24) return `in ${h}h ${m % 60}m`;
  return 'in ' + Math.floor(h / 24) + 'd';
}

// ---------- Notification scheduling ----------
async function scheduleTaskAlarms(task) {
  const ids = [];
  if (!task.alarm || task.done) return ids;
  const times = upcomingOccurrences(task, MAX_SCHEDULED_PER_TASK);
  for (const ms of times) {
    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: '⏰ ' + task.title,
        body: task.desc || "Time's up!",
        sound: 'default',
        ...(Platform.OS === 'android' ? {} : {}),
      },
      trigger: Platform.OS === 'android'
        ? { date: new Date(ms), channelId: 'alarms' }
        : { date: new Date(ms) },
    });
    ids.push(id);
  }
  return ids;
}

async function rescheduleAll(tasks) {
  await Notifications.cancelAllScheduledNotificationsAsync();
  const updated = [];
  for (const t of tasks) {
    const notifIds = await scheduleTaskAlarms(t);
    updated.push({ ...t, notifIds });
  }
  return updated;
}

// ---------- App ----------
export default function App() {
  const [tasks, setTasks] = useState([]);
  const [loaded, setLoaded] = useState(false);

  // form state
  const [title, setTitle] = useState('');
  const [desc, setDesc] = useState('');
  const [dueDate, setDueDate] = useState(null); // Date or null
  const [dueTime, setDueTime] = useState(null); // Date (time part) or null
  const [alarm, setAlarm] = useState(false);
  const [repeat, setRepeat] = useState('');
  const [days, setDays] = useState([0, 1, 2, 3, 4, 5, 6]);
  const [endRepeatOn, setEndRepeatOn] = useState(false);
  const [endDate, setEndDate] = useState(null);
  const [picker, setPicker] = useState(null); // 'date' | 'time' | 'end' | null

  // load + permissions
  useEffect(() => {
    (async () => {
      await ensurePermissions();
      await ensureAndroidChannel();
      try {
        const raw = await AsyncStorage.getItem('chime.tasks');
        let list = raw ? JSON.parse(raw) : [];
        // keep notification schedule fresh on every launch
        list = await rescheduleAll(list);
        list.sort((a, b) => (a.due || Infinity) - (b.due || Infinity));
        setTasks(list);
        await AsyncStorage.setItem('chime.tasks', JSON.stringify(list));
      } catch (e) {
        setTasks([]);
      }
      setLoaded(true);
    })();
  }, []);

  const persist = useCallback(async (list) => {
    list.sort((a, b) => (a.due || Infinity) - (b.due || Infinity));
    setTasks([...list]);
    await AsyncStorage.setItem('chime.tasks', JSON.stringify(list));
  }, []);

  const resetForm = () => {
    setTitle(''); setDesc(''); setDueDate(null); setDueTime(null);
    setAlarm(false); setRepeat(''); setDays([0, 1, 2, 3, 4, 5, 6]);
    setEndRepeatOn(false); setEndDate(null); setPicker(null);
  };

  const addTask = async () => {
    if (!title.trim()) { Alert.alert('Title is required'); return; }
    if (alarm && (!dueDate || !dueTime)) { Alert.alert('Pick a date and time for the alarm.'); return; }
    if (repeat && !dueDate) { Alert.alert('Pick a date for a repeating task.'); return; }
    if (repeat === 'daily' && days.length === 0) { Alert.alert('Pick at least one day.'); return; }

    let due = null;
    if (dueDate) {
      const d = new Date(dueDate);
      if (dueTime) { d.setHours(dueTime.getHours(), dueTime.getMinutes(), 0, 0); }
      else { d.setHours(9, 0, 0, 0); }
      due = d.getTime();
    }
    if (due && repeat === 'daily' && !days.includes(new Date(due).getDay())) {
      due = nextOccurrence(due, 'daily', days); // snap to first selected day
    }
    let endRepeat = null;
    if (repeat && endRepeatOn && endDate) {
      const e = new Date(endDate); e.setHours(23, 59, 59, 0);
      endRepeat = e.getTime();
      if (due && endRepeat < due) { Alert.alert('End repeat must be after the first occurrence.'); return; }
    }

    const task = {
      id: Date.now() + Math.random().toString(16).slice(2),
      title: title.trim(), desc: desc.trim(), due, alarm,
      repeat: repeat || null, days: repeat === 'daily' ? [...days] : null,
      endRepeat, done: false, notifIds: [], created: Date.now(),
    };
    if (task.alarm) {
      const ok = await ensurePermissions();
      if (!ok) Alert.alert('Notifications are off', 'Enable them in Settings for alarms to ring.');
      task.notifIds = await scheduleTaskAlarms(task);
    }
    await persist([...tasks, task]);
    resetForm();
  };

  const toggleDone = async (task) => {
    const list = tasks.map((t) => ({ ...t }));
    const t = list.find((x) => x.id === task.id);
    for (const nid of t.notifIds || []) await Notifications.cancelScheduledNotificationAsync(nid).catch(() => {});
    t.notifIds = [];
    if (!t.done && t.repeat) {
      if (advanceRecurring(t)) t.notifIds = await scheduleTaskAlarms(t);
      else t.done = true; // series ended
    } else {
      t.done = !t.done;
      if (!t.done) t.notifIds = await scheduleTaskAlarms(t); // un-completing re-arms
    }
    await persist(list);
  };

  const removeTask = async (task) => {
    for (const nid of task.notifIds || []) await Notifications.cancelScheduledNotificationAsync(nid).catch(() => {});
    await persist(tasks.filter((t) => t.id !== task.id));
  };

  const toggleDay = (d) =>
    setDays((prev) => (prev.includes(d) ? prev.filter((x) => x !== d) : [...prev, d]));

  const onPick = (event, selected) => {
    if (Platform.OS === 'android') setPicker(null);
    if (!selected) return;
    if (picker === 'date') setDueDate(selected);
    if (picker === 'time') setDueTime(selected);
    if (picker === 'end') setEndDate(selected);
  };

  const open = tasks.filter((t) => !t.done).length;

  return (
    <SafeAreaView style={s.safe}>
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
        <ScrollView contentContainerStyle={s.wrap} keyboardShouldPersistTaps="handled">
          <View style={s.header}>
            <Text style={s.h1}>Chime<Text style={{ color: C.signal }}>.</Text></Text>
          </View>

          {/* ---- Form ---- */}
          <View style={s.card}>
            <Text style={s.label}>TITLE</Text>
            <TextInput style={s.input} value={title} onChangeText={setTitle}
              placeholder="What needs doing?" placeholderTextColor={C.muted} maxLength={120} />

            <Text style={s.label}>DESCRIPTION</Text>
            <TextInput style={[s.input, s.multiline]} value={desc} onChangeText={setDesc}
              placeholder="Optional details…" placeholderTextColor={C.muted} multiline maxLength={1000} />

            <View style={s.row2}>
              <View style={{ flex: 1 }}>
                <Text style={s.label}>DATE</Text>
                <TouchableOpacity style={s.input} onPress={() => setPicker(picker === 'date' ? null : 'date')}>
                  <Text style={dueDate ? s.inputText : s.placeholder}>
                    {dueDate ? dueDate.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : 'Pick date'}
                  </Text>
                </TouchableOpacity>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={s.label}>TIME</Text>
                <TouchableOpacity style={s.input} onPress={() => setPicker(picker === 'time' ? null : 'time')}>
                  <Text style={dueTime ? s.inputText : s.placeholder}>
                    {dueTime ? dueTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Pick time'}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            {picker === 'date' && (
              <DateTimePicker value={dueDate || new Date()} mode="date" minimumDate={new Date()}
                display={Platform.OS === 'ios' ? 'inline' : 'default'} onChange={onPick} />
            )}
            {picker === 'time' && (
              <DateTimePicker value={dueTime || new Date()} mode="time"
                display={Platform.OS === 'ios' ? 'spinner' : 'default'} onChange={onPick} />
            )}

            <Text style={s.label}>REPEAT</Text>
            <View style={s.pillRow}>
              {REPEATS.map((r) => (
                <TouchableOpacity key={r.key || 'never'}
                  style={[s.pill, repeat === r.key && s.pillOn]}
                  onPress={() => setRepeat(r.key)}>
                  <Text style={[s.pillText, repeat === r.key && s.pillTextOn]}>{r.label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {repeat === 'daily' && (
              <>
                <Text style={s.label}>REPEAT ON DAYS</Text>
                <View style={s.pillRow}>
                  {DAY_ORDER.map((d) => (
                    <TouchableOpacity key={d}
                      style={[s.dayPill, days.includes(d) && s.pillOn]}
                      onPress={() => toggleDay(d)}>
                      <Text style={[s.pillText, days.includes(d) && s.pillTextOn]}>{DAY_SHORT[d]}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </>
            )}

            {!!repeat && (
              <View style={s.switchRow}>
                <View style={{ flex: 1 }}>
                  <Text style={s.switchTitle}>End repeat</Text>
                  <Text style={s.switchSub}>{endRepeatOn ? 'Stops after the date below' : 'Repeats forever'}</Text>
                </View>
                <Switch value={endRepeatOn} onValueChange={setEndRepeatOn}
                  trackColor={{ true: C.cobalt }} />
              </View>
            )}
            {!!repeat && endRepeatOn && (
              <TouchableOpacity style={s.input} onPress={() => setPicker(picker === 'end' ? null : 'end')}>
                <Text style={endDate ? s.inputText : s.placeholder}>
                  {endDate ? 'Until ' + endDate.toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }) : 'Pick end date'}
                </Text>
              </TouchableOpacity>
            )}
            {picker === 'end' && (
              <DateTimePicker value={endDate || dueDate || new Date()} mode="date"
                minimumDate={dueDate || new Date()}
                display={Platform.OS === 'ios' ? 'inline' : 'default'} onChange={onPick} />
            )}

            <View style={[s.switchRow, s.alarmRow]}>
              <View style={{ flex: 1 }}>
                <Text style={s.switchTitle}>Urgent — ring alarm</Text>
                <Text style={s.switchSub}>Rings even when the app is closed</Text>
              </View>
              <Switch value={alarm} onValueChange={setAlarm} trackColor={{ true: C.signal }} />
            </View>

            <TouchableOpacity style={s.addBtn} onPress={addTask}>
              <Text style={s.addBtnText}>Add task</Text>
            </TouchableOpacity>
          </View>

          {/* ---- List ---- */}
          <Text style={s.section}>Tasks ({open} open)</Text>
          {loaded && tasks.length === 0 && (
            <View style={[s.card, { alignItems: 'center' }]}>
              <Text style={{ color: C.muted }}>No tasks yet — add your first one above.</Text>
            </View>
          )}
          {tasks.map((t) => {
            const overdue = t.due && !t.done && t.due < Date.now();
            return (
              <View key={t.id} style={[s.task, overdue && s.taskOverdue, t.done && { opacity: 0.5 }]}>
                <TouchableOpacity style={[s.check, t.done && s.checkOn]} onPress={() => toggleDone(t)}>
                  {t.done && <Text style={s.checkMark}>✓</Text>}
                </TouchableOpacity>
                <View style={{ flex: 1 }}>
                  <Text style={[s.tTitle, t.done && { textDecorationLine: 'line-through' }]}>{t.title}</Text>
                  {!!t.desc && <Text style={s.tDesc}>{t.desc}</Text>}
                  <View style={s.metaRow}>
                    {!!t.due && <Text style={s.chip}>{fmtDue(t.due)}</Text>}
                    {!!t.due && !t.done && (
                      <Text style={[s.chip, s.chipCount, overdue && s.chipLate]}>{countdownText(t.due)}</Text>
                    )}
                    {!!t.repeat && (
                      <Text style={[s.chip, s.chipRepeat]}>
                        ↻ {repeatLabel(t)}{t.endRepeat ? ' until ' + new Date(t.endRepeat).toLocaleDateString([], { month: 'short', day: 'numeric' }) : ''}
                      </Text>
                    )}
                    {!!t.alarm && <Text style={[s.chip, s.chipAlarm]}>⏰ alarm</Text>}
                  </View>
                </View>
                <TouchableOpacity onPress={() => removeTask(t)} style={s.del}>
                  <Text style={{ color: C.muted, fontSize: 18 }}>×</Text>
                </TouchableOpacity>
              </View>
            );
          })}
          <Text style={s.note}>Alarms use system notifications — allow them when prompted.</Text>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

// ---------- Styles ----------
const s = StyleSheet.create({
  safe: { flex: 1, backgroundColor: C.bg },
  wrap: { padding: 16, paddingBottom: 60 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 14 },
  h1: { fontSize: 28, fontWeight: '800', color: C.ink, letterSpacing: -0.5 },
  card: { backgroundColor: C.surface, borderColor: C.line, borderWidth: 1, borderRadius: 14, padding: 16, marginBottom: 8 },
  label: { fontSize: 11, fontWeight: '700', color: C.muted, letterSpacing: 0.8, marginBottom: 5, marginTop: 12 },
  input: { borderWidth: 1, borderColor: C.line, borderRadius: 10, padding: 12, backgroundColor: '#FBFCFE', justifyContent: 'center' },
  inputText: { color: C.ink, fontSize: 15 },
  placeholder: { color: C.muted, fontSize: 15 },
  multiline: { minHeight: 60, textAlignVertical: 'top' },
  row2: { flexDirection: 'row', gap: 12 },
  pillRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6 },
  pill: { borderWidth: 1, borderColor: C.line, backgroundColor: '#FBFCFE', borderRadius: 999, paddingVertical: 8, paddingHorizontal: 14 },
  dayPill: { borderWidth: 1, borderColor: C.line, backgroundColor: '#FBFCFE', borderRadius: 999, paddingVertical: 8, width: '12.5%', minWidth: 44, alignItems: 'center' },
  pillOn: { backgroundColor: C.cobalt, borderColor: C.cobalt },
  pillText: { color: C.muted, fontSize: 13, fontWeight: '600' },
  pillTextOn: { color: '#fff' },
  switchRow: { flexDirection: 'row', alignItems: 'center', marginTop: 14, gap: 10 },
  alarmRow: { backgroundColor: C.signalSoft, borderColor: '#FFD9C4', borderWidth: 1, borderRadius: 10, padding: 12 },
  switchTitle: { fontWeight: '600', color: C.ink, fontSize: 14 },
  switchSub: { color: C.muted, fontSize: 12, marginTop: 2 },
  addBtn: { backgroundColor: C.cobalt, borderRadius: 10, padding: 14, alignItems: 'center', marginTop: 16 },
  addBtnText: { color: '#fff', fontWeight: '700', fontSize: 15 },
  section: { fontWeight: '700', color: C.muted, marginVertical: 12, fontSize: 14 },
  task: { backgroundColor: C.surface, borderColor: C.line, borderWidth: 1, borderRadius: 14, padding: 14, marginBottom: 10, flexDirection: 'row', gap: 12, alignItems: 'flex-start' },
  taskOverdue: { borderColor: C.signal },
  check: { width: 22, height: 22, borderRadius: 6, borderWidth: 2, borderColor: C.line, marginTop: 2, alignItems: 'center', justifyContent: 'center' },
  checkOn: { backgroundColor: C.green, borderColor: C.green },
  checkMark: { color: '#fff', fontSize: 13, fontWeight: '800' },
  tTitle: { fontWeight: '600', fontSize: 15, color: C.ink },
  tDesc: { color: C.muted, fontSize: 13, marginTop: 2 },
  metaRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginTop: 8 },
  chip: { fontSize: 12, fontWeight: '600', color: C.cobalt, backgroundColor: C.cobaltSoft, paddingVertical: 3, paddingHorizontal: 9, borderRadius: 999, overflow: 'hidden' },
  chipCount: { color: C.muted, backgroundColor: '#EEF1F6' },
  chipLate: { color: '#fff', backgroundColor: C.signal },
  chipRepeat: { color: C.green, backgroundColor: C.greenSoft },
  chipAlarm: { color: C.signal, backgroundColor: C.signalSoft },
  del: { padding: 4 },
  note: { textAlign: 'center', color: C.muted, fontSize: 12, marginTop: 16 },
});
